
public class Masajista extends SeleccionFutbol
{
    String titulacion;
    Integer años;
    public Masajista()
    {
        
    }
  
     public Masajista(String titulacion,Integer años,Integer id,String nombre,String apellidos,Integer edad)
    {
      super(id,nombre,apellidos,edad);
      this.titulacion=titulacion;
      this.años=años;
    }

    public String getTitulacion() {
        return titulacion;
    }

    public void setTitulacion(String titulacion) {
        this.titulacion = titulacion;
    }

    public Integer getAños() {
        return años;
    }

    public void setAños(Integer años) {
        this.años = años;
    }
}
