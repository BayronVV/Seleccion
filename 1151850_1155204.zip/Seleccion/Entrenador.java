
public class Entrenador extends SeleccionFutbol
{
   String federacion;
    public Entrenador()
    {
    }
    public Entrenador(String federacion,Integer id,String nombre,String apellidos,Integer edad)
    {
        super(id,nombre,apellidos,edad);
        this.federacion=federacion;
    }
    public void setfederacion(String federacion)
    {
      this.federacion=federacion;
    }
    public String getfederacion()
    {
        return federacion;
    }
}
