public class Futbolista extends SeleccionFutbol
{
    String seleccion;
    Integer dorsal;
    String demarcacion;
    Entrenador entrenador = new Entrenador();
    public Futbolista()
    {
      
    }
    public Futbolista(String seleccion, Integer dorsal, String demarcacion,Integer id,String nombre,String apellidos,Integer edad)
    {
      super(id,nombre,apellidos,edad);
      this.seleccion=seleccion;
      this.dorsal=dorsal;
      this.demarcacion=demarcacion;
    }
    public String getSeleccion() {
        return seleccion;
    }

    public void setSeleccion(String seleccion) {
        this.seleccion = seleccion;
    }

    public Integer getDorsal() {
        return dorsal;
    }

    public void setDorsal(Integer dorsal) {
        this.dorsal = dorsal;
    }

    public String getDemarcacion() {
        return demarcacion;
    }

    public void setDemarcacion(String demarcacion) {
        this.demarcacion = demarcacion;
    }
    public void mostrar()
    {
       System.out.println("El nombre del futbolista es: "+nombre+" su dorsal es: "+dorsal+" su posicion: "+demarcacion+" y su entrenador es: "+entrenador.nombre);
    }
    
}
